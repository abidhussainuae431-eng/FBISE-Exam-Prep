# FBISE Exam Prep App
This project is for 9th & 10th class students to prepare for SSC exams.
